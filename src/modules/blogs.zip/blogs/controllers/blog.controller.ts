import { Controller, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { BlogService } from '../services/blog/blog.service';
import { CreateBlogPostDto } from '../dto/create-blog-post.dto';
import { UpdateBlogPostDto } from '../dto/update-blog-post.dto';
import { CreatePostCommentDto } from '../dto/create-post-comment.dto';
import { TogglePostReactionDto } from '../dto/toggle-post-reaction.dto';
import { ToggleCommentReactionDto } from '../dto/toggle-comment-reaction.dto';

@Controller('blog')
export class BlogController {
  constructor(private readonly blogService: BlogService) {}

  // Blog Post Endpoints

  @Post('posts')
  createBlogPost(@Body() createBlogPostDto: CreateBlogPostDto) {
    return this.blogService.createBlogPost(createBlogPostDto);
  }

  @Put('posts/:id')
  updateBlogPost(
    @Param('id') id: string,
    @Body() updateBlogPostDto: UpdateBlogPostDto,
  ) {
    return this.blogService.updateBlogPost(id, updateBlogPostDto);
  }

  @Delete('posts/:id')
  deleteBlogPost(@Param('id') id: string) {
    return this.blogService.deleteBlogPost(id);
  }

  // Comment Endpoints

  @Post('comments')
  createPostComment(@Body() createPostCommentDto: CreatePostCommentDto) {
    return this.blogService.createPostComment(createPostCommentDto);
  }

  // Post Reaction Endpoints

  @Post('posts/reactions')
  togglePostReaction(@Body() togglePostReactionDto: TogglePostReactionDto) {
    return this.blogService.togglePostReaction(togglePostReactionDto);
  }

  // Comment Reaction Endpoints

  @Post('comments/reactions')
  toggleCommentReaction(
    @Body() toggleCommentReactionDto: ToggleCommentReactionDto,
  ) {
    return this.blogService.toggleCommentReaction(toggleCommentReactionDto);
  }
}
