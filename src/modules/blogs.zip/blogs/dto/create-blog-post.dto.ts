import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsOptional,
  IsString,
  IsDate,
  IsUrl,
} from 'class-validator';

export class CreateBlogPostDto {
  @ApiProperty({ description: 'Title of the blog post' })
  @IsNotEmpty()
  @IsString()
  title: string;

  @ApiProperty({ description: 'Summary or excerpt of the blog post' })
  @IsOptional()
  @IsString()
  summary?: string;

  @ApiProperty({ description: 'Main content of the blog post' })
  @IsNotEmpty()
  @IsString()
  content: string;

  @ApiProperty({ description: 'Category of the blog post' })
  @IsOptional()
  @IsString()
  category?: string;

  @ApiProperty({ description: 'URL to the featured image' })
  @IsOptional()
  @IsUrl()
  featuredImageUrl?: string;

  @ApiProperty({
    description: 'Author ID, reference to the member who created the post',
  })
  @IsNotEmpty()
  @IsString()
  authorId: string;

  @ApiProperty({
    description: 'Date and time when the post was published',
    required: false,
  })
  @IsOptional()
  @IsDate()
  publishedAt?: Date;
}
