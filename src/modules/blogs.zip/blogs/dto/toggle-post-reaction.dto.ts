import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  IsBoolean,
} from 'class-validator';

export class TogglePostReactionDto {
  @ApiProperty({ description: 'The ID of the blog post to react to' })
  @IsNotEmpty()
  @IsString()
  postId: string;

  @ApiProperty({ description: 'User ID of the person reacting' })
  @IsNotEmpty()
  @IsString()
  userId: string;

  @ApiProperty({ description: 'The type of reaction (like or dislike)' })
  @IsNotEmpty()
  @IsEnum(['like', 'dislike'])
  reactionType: 'like' | 'dislike';

  @ApiProperty({
    description: 'Indicates whether the reaction should be removed',
    required: false,
  })
  @IsOptional()
  @IsBoolean()
  remove?: boolean; // Optional flag to indicate if the reaction should be removed
}
