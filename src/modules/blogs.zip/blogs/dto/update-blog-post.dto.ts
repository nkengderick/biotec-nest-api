import { ApiProperty } from '@nestjs/swagger';
import {
  IsOptional,
  IsString,
  IsDate,
  IsUrl,
} from 'class-validator';

export class UpdateBlogPostDto {
  @ApiProperty({ description: 'Title of the blog post', required: false })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiProperty({
    description: 'Summary or excerpt of the blog post',
    required: false,
  })
  @IsOptional()
  @IsString()
  summary?: string;

  @ApiProperty({
    description: 'Main content of the blog post',
    required: false,
  })
  @IsOptional()
  @IsString()
  content?: string;

  @ApiProperty({ description: 'Category of the blog post', required: false })
  @IsOptional()
  @IsString()
  category?: string;

  @ApiProperty({ description: 'URL to the featured image', required: false })
  @IsOptional()
  @IsUrl()
  featuredImageUrl?: string;

  @ApiProperty({
    description: 'Date and time when the post was published',
    required: false,
  })
  @IsOptional()
  @IsDate()
  publishedAt?: Date;
}
