import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsOptional } from 'class-validator';

export class CreatePostCommentDto {
  @ApiProperty({ description: 'The ID of the blog post to comment on' })
  @IsNotEmpty()
  @IsString()
  postId: string;

  @ApiProperty({ description: 'User ID of the person making the comment' })
  @IsNotEmpty()
  @IsString()
  userId: string;

  @ApiProperty({ description: 'The text content of the comment' })
  @IsNotEmpty()
  @IsString()
  commentText: string;
}