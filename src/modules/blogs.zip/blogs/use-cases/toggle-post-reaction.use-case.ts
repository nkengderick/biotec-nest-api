import { Injectable } from '@nestjs/common';
import { PostReactionRepository } from '../repositories/post-reaction.repository';
import { TogglePostReactionDto } from '../dto/toggle-post-reaction.dto';
import { PostReaction } from '../schemas/post-reaction.schema';

@Injectable()
export class TogglePostReactionUseCase {
  constructor(
    private readonly postReactionRepository: PostReactionRepository,
  ) {}

  async execute(
    togglePostReactionDto: TogglePostReactionDto,
  ): Promise<PostReaction | null> {
    const { postId, userId, reactionType, remove } = togglePostReactionDto;

    // Find if the user has already reacted to the post
    const existingReaction =
      await this.postReactionRepository.findByPostIdAndUserId(postId, userId);

    // If a reaction exists and the user wants to remove it
    if (existingReaction && remove) {
      await this.postReactionRepository.delete(existingReaction._id);
      return null; // No reaction after removal
    }

    // If a reaction exists but the type differs, switch the reaction type
    if (existingReaction && existingReaction.reactionType !== reactionType) {
      return this.postReactionRepository.updateReactionType(
        existingReaction._id,
        reactionType,
      );
    }

    // If no reaction exists, create a new one
    if (!existingReaction) {
      return this.postReactionRepository.createOrUpdate(togglePostReactionDto);
    }

    return existingReaction; // Return the existing reaction if no changes were made
  }
}
