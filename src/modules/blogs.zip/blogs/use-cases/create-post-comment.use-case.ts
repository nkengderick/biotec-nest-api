import { Injectable } from '@nestjs/common';
import { PostCommentRepository } from '../repositories/post-comment.repository';
import { CreatePostCommentDto } from '../dto/create-post-comment.dto';
import { PostComment } from '../schemas/post-comment.schema';

@Injectable()
export class CreatePostCommentUseCase {
  constructor(private readonly postCommentRepository: PostCommentRepository) {}

  async execute(
    createPostCommentDto: CreatePostCommentDto,
  ): Promise<PostComment> {
    return this.postCommentRepository.create(createPostCommentDto);
  }
}
