import { Injectable } from '@nestjs/common';
import { BlogPostRepository } from '../repositories/blog-post.repository';
import { UpdateBlogPostDto } from '../dto/update-blog-post.dto';
import { BlogPost } from '../schemas/blog-post.schema';

@Injectable()
export class UpdateBlogPostUseCase {
  constructor(private readonly blogPostRepository: BlogPostRepository) {}

  async execute(
    id: string,
    updateBlogPostDto: UpdateBlogPostDto,
  ): Promise<BlogPost> {
    return this.blogPostRepository.update(id, updateBlogPostDto);
  }
}
