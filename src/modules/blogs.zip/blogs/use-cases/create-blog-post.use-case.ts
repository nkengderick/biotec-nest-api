import { Injectable } from '@nestjs/common';
import { BlogPostRepository } from '../repositories/blog-post.repository';
import { CreateBlogPostDto } from '../dto/create-blog-post.dto';
import { BlogPost } from '../schemas/blog-post.schema';

@Injectable()
export class CreateBlogPostUseCase {
  constructor(private readonly blogPostRepository: BlogPostRepository) {}

  async execute(createBlogPostDto: CreateBlogPostDto): Promise<BlogPost> {
    return this.blogPostRepository.create(createBlogPostDto);
  }
}
