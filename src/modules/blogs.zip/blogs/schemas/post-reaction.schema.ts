import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { ApiProperty } from '@nestjs/swagger';

export type PostReactionDocument = PostReaction & Document;

@Schema({ timestamps: true })
export class PostReaction {
  @ApiProperty({ description: 'Unique identifier for the reaction' })
  @Prop({ required: true, unique: true })
  reactionId: number;

  @ApiProperty({
    description: 'Blog post ID, reference to the associated blog post',
  })
  @Prop({ required: true })
  postId: number;

  @ApiProperty({ description: 'User ID, reference to the user who reacted' })
  @Prop({ required: true })
  userId: number;

  @ApiProperty({
    description: 'Reaction type: either "like" or "dislike"',
    enum: ['like', 'dislike'],
  })
  @Prop({ required: true, enum: ['like', 'dislike'] })
  reactionType: string;
}

export const PostReactionSchema = SchemaFactory.createForClass(PostReaction);
