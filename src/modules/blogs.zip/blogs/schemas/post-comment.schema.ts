import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { ApiProperty } from '@nestjs/swagger';

export type PostCommentDocument = PostComment & Document;

@Schema({ timestamps: true })
export class PostComment {
  @ApiProperty({ description: 'Unique identifier for the comment' })
  @Prop({ required: true, unique: true })
  commentId: number;

  @ApiProperty({
    description: 'Blog post ID, reference to the associated blog post',
  })
  @Prop({ required: true })
  postId: number;

  @ApiProperty({
    description: 'User ID, reference to the user who made the comment',
  })
  @Prop({ required: true })
  userId: number;

  @ApiProperty({ description: 'The text content of the comment' })
  @Prop({ required: true })
  commentText: string;
}

export const PostCommentSchema = SchemaFactory.createForClass(PostComment);
