import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { ApiProperty } from '@nestjs/swagger';

export type CommentReactionDocument = CommentReaction & Document;

@Schema({ timestamps: true })
export class CommentReaction {
  @ApiProperty({ description: 'Unique identifier for the comment reaction' })
  @Prop({ required: true, unique: true })
  reactionId: number;

  @ApiProperty({
    description: 'Comment ID, reference to the associated comment',
  })
  @Prop({ required: true })
  commentId: number;

  @ApiProperty({ description: 'User ID, reference to the user who reacted' })
  @Prop({ required: true })
  userId: number;

  @ApiProperty({
    description: 'Reaction type: either "like" or "dislike"',
    enum: ['like', 'dislike'],
  })
  @Prop({ required: true, enum: ['like', 'dislike'] })
  reactionType: string;
}

export const CommentReactionSchema =
  SchemaFactory.createForClass(CommentReaction);
